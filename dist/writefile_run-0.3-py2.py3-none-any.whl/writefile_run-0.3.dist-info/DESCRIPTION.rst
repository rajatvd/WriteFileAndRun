IPython cell magic which builds on top of the writefile cell magic. It also optionally runs the cell after writing it to the file.


